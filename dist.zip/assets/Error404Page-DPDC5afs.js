import{j as e}from"./index-DpNGNyzJ.js";import"./react-dom-B_KBoKIY.js";function a(){return console.log("Error404"),e.jsxs("h1",{children:["错误 ",">_<"," 404"]})}export{a as default};
